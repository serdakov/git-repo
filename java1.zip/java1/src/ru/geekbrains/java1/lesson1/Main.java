package ru.geekbrains.java1.lesson1;

public class Main {
    public static void main(String[] args) {
        System.out.println("привет мир!!!!");
        byte b = 121;
        System.out.println("b= " + b);

        int i;
        i = 45676554;
        System.out.println("i= " + i);

        long l = 211115555556665567L;
        System.out.println("l= " + l);

        float f = 456.6F;
        double d = 43546.7;

        boolean bool = true;
        System.out.println("bool = " + bool);
        bool = false;
        System.out.println("bool = " + bool);

        String s = "строка";
        System.out.println("s= " + s);

        char c = 'g';

        int a, v;
        a = 10;
        v = 20;
        b = 50;

        a = a + v;
        System.out.println(a);

        a += v;
        a = b + v;

        int g = a + v;

        g++;
        System.out.println(g);
        System.out.println(a);

        int j = ++g + a;
        System.out.println(j);
        System.out.println(g);

        a = 10;
        b = 50;
        if (a < b) {
            System.out.println("больше");
            System.out.println("+++");
        } else {
            System.out.println("меньше");
        }




    }
}
